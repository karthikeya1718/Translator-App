import { z, _ } from "../chunks/2.BtNuv8FW.js";
export {
  z as component,
  _ as universal
};
